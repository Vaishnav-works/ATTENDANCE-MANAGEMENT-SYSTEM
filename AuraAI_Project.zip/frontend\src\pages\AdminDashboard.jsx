import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Users, BookOpen, ShieldCheck, X, Server } from 'lucide-react';
import API from '../api/api';
import ProfileSection from '../components/ProfileSection';

const AdminDashboard = () => {
  const { user } = useAuth();
  
  const [showUserModal, setShowUserModal] = useState(false);
  const [showSubjectModal, setShowSubjectModal] = useState(false);
  const [message, setMessage] = useState('');
  
  const [subjects, setSubjects] = useState([]);

  // Form States - User
  const [uName, setUName] = useState('');
  const [uEmail, setUEmail] = useState('');
  const [uRole, setURole] = useState('Student');

  // Form States - Subject
  const [sCode, setSCode] = useState('');
  const [sName, setSName] = useState('');
  const [sBranch, setSBranch] = useState('');
  const [sYear, setSYear] = useState('');
  const [sSemester, setSSemester] = useState('Fall');
  const [sTime, setSTime] = useState('');

  // Load registered subjects on mount
  const fetchSubjects = async () => {
    try {
      const res = await API.get('/subjects');
      setSubjects(res.data);
    } catch (err) {
      console.error("Failed to load subjects:", err);
    }
  };

  useEffect(() => {
     fetchSubjects();
  }, []);

  const handleAddUser = (e) => {
    e.preventDefault();
    setMessage(`Successfully created ${uRole}: ${uName}`);
    setShowUserModal(false);
    setTimeout(() => setMessage(''), 3000);
  };

  const handleAddSubject = async (e) => {
    e.preventDefault();
    console.log("Admin initiating subject registration...");
    try {
       const newSubject = {
          subject_id: sCode,
          subject_code: sCode,
          subject_name: sName,
          branch: sBranch.toUpperCase(),
          year: parseInt(sYear),
          semester: sSemester,
          class_time: sTime
       };

       const res = await API.post('/subjects', newSubject);

       if (res.status === 200 || res.status === 201) {
          setMessage(`Successfully registered: ${sName}`);
          setShowSubjectModal(false);
          setSCode('');
          setSName('');
          setSBranch('');
          setSYear('');
          fetchSubjects(); 
          setTimeout(() => setMessage(''), 5000);
       } else {
          setMessage(`Error: ${res.data?.message || 'Failed to save subject'}`);
          setTimeout(() => setMessage(''), 5000);
       }
    } catch (err) {
       console.error("Browser Fetch Error:", err);
       setMessage(`System Error: ${err.response?.data?.message || err.message}`);
       setTimeout(() => setMessage(''), 5000);
    }
  };

  return (
    <div className="space-y-6 relative">
      <ProfileSection user={user} />

      {message && (
        <div className={`fixed top-4 right-4 p-4 rounded-lg shadow-2xl z-[100] border backdrop-blur-md animate-in fade-in slide-in-from-top-4 duration-300 ${
           message.startsWith('Error') || message.startsWith('System') 
           ? 'bg-red-500/20 border-red-500 text-red-200' 
           : 'bg-green-500/20 border-green-500 text-green-200'
        }`}>
          <div className="flex items-center gap-3">
             <div className={`w-2 h-2 rounded-full ${message.startsWith('Error') ? 'bg-red-500' : 'bg-green-500'}`}></div>
             <p className="font-bold tracking-wide">{message}</p>
          </div>
        </div>
      )}

      <header className="hidden">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-red-400 to-[#6366F1] bg-clip-text text-transparent">
          Admin Control Center
        </h1>
        <p className="text-gray-400 mt-2">Manage all system users, classes, and site-wide metadata.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="glass-card p-6 flex flex-col justify-between border-t-4 border-t-blue-500">
           <div className="flex justify-between items-start">
             <p className="text-gray-400">Total Students</p>
             <Users className="w-6 h-6 text-blue-500" />
           </div>
           <h3 className="text-3xl font-bold mt-4">142</h3>
        </div>
        <div className="glass-card p-6 flex flex-col justify-between border-t-4 border-t-green-500">
           <div className="flex justify-between items-start">
             <p className="text-gray-400">Total Faculty</p>
             <ShieldCheck className="w-6 h-6 text-green-500" />
           </div>
           <h3 className="text-3xl font-bold mt-4">18</h3>
        </div>
        <div className="md:col-span-2 glass-card p-6 flex flex-col justify-between border-t-4 border-t-purple-500 bg-purple-500/5">
           <div className="flex justify-between items-start mb-2">
             <p className="text-purple-300 font-semibold">Total Subjects Semester-wise</p>
             <Server className="w-6 h-6 text-purple-500" />
           </div>
           <div className="grid grid-cols-2 gap-4 mt-2 border-t border-purple-500/20 pt-4">
               <div>
                   <p className="text-xs text-gray-400 uppercase tracking-wider">Fall Semester</p>
                   <p className="text-2xl font-bold text-white">{subjects.filter(s => s.semester === 'Fall').length} <span className="text-sm font-normal text-gray-500">active</span></p>
               </div>
               <div>
                   <p className="text-xs text-gray-400 uppercase tracking-wider">Spring Semester</p>
                   <p className="text-2xl font-bold text-white">{subjects.filter(s => s.semester === 'Spring').length} <span className="text-sm font-normal text-gray-500">active</span></p>
               </div>
           </div>
        </div>
      </div>
      
      <div className="glass-card p-6 mt-8">
         <h2 className="text-xl font-semibold mb-4 text-white">System Actions</h2>
         <div className="flex gap-4 flex-wrap">
            <button onClick={() => setShowUserModal(true)} className="primary-button bg-white/10 hover:bg-white/20 text-white border border-white/20">Add New User</button>
            <button onClick={() => setShowSubjectModal(true)} className="primary-button bg-white/10 hover:bg-white/20 text-white border border-white/20">Register Subject (Branch/Year)</button>
            <button className="primary-button bg-red-500/20 hover:bg-red-500/40 text-red-300 border border-red-500/30 cursor-not-allowed opacity-50">System Audit Log (Locked)</button>
         </div>
      </div>

      {/* Add User Modal */}
      {showUserModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-md relative border-[#6366F1]/50">
            <button onClick={() => setShowUserModal(false)} className="absolute top-4 right-4 text-gray-400 hover:text-white"><X /></button>
            <h2 className="text-2xl font-bold mb-4">Add New User</h2>
            <form onSubmit={handleAddUser} className="space-y-4">
              <div>
                 <label className="block text-sm text-gray-400 mb-1">Full Name</label>
                 <input type="text" required value={uName} onChange={e=>setUName(e.target.value)} className="w-full p-2 bg-white/5 border border-white/10 rounded text-white focus:border-[#6366F1] outline-none" />
              </div>
              <div>
                 <label className="block text-sm text-gray-400 mb-1">Email</label>
                 <input type="email" required value={uEmail} onChange={e=>setUEmail(e.target.value)} className="w-full p-2 bg-white/5 border border-white/10 rounded text-white focus:border-[#6366F1] outline-none" />
              </div>
              <div>
                 <label className="block text-sm text-gray-400 mb-1">Role</label>
                 <select value={uRole} onChange={e=>setURole(e.target.value)} className="w-full p-2 bg-[#121212] border border-white/10 rounded text-white focus:border-[#6366F1] outline-none">
                    <option value="Student">Student</option>
                    <option value="Faculty">Faculty</option>
                    <option value="Admin">Admin</option>
                 </select>
              </div>
              <button type="submit" className="w-full primary-button mt-4">Create User</button>
            </form>
          </div>
        </div>
      )}

      {/* Add Subject Modal with Branch, Year and Semester */}
      {showSubjectModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-50 p-4">
          <div className="glass-card p-6 w-full max-w-lg relative border-purple-500/50 shadow-2xl">
            <button onClick={() => setShowSubjectModal(false)} className="absolute top-4 right-4 text-gray-400 hover:text-white"><X /></button>
            <h2 className="text-2xl font-bold mb-6 text-purple-300 border-b border-white/10 pb-2">Register Subject</h2>
            
            <form onSubmit={handleAddSubject} className="space-y-5">
              <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-1">Subject Code</label>
                    <input type="text" placeholder="e.g. CS101" required value={sCode} onChange={e=>setSCode(e.target.value)} className="w-full p-2.5 bg-black/40 border border-white/10 rounded text-white focus:border-purple-500 outline-none transition-colors shadow-inner" />
                 </div>
                 <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-1">Semester</label>
                    <select required value={sSemester} onChange={e=>setSSemester(e.target.value)} className="w-full p-2.5 bg-black/60 border border-white/10 rounded text-white focus:border-purple-500 outline-none transition-colors">
                       <option value="Fall">Fall Semester</option>
                       <option value="Spring">Spring Semester</option>
                       <option value="Summer">Summer Term</option>
                    </select>
                 </div>
              </div>

              <div>
                 <label className="block text-sm font-semibold text-gray-300 mb-1">Full Subject Name</label>
                 <input type="text" placeholder="Introduction to Computer Science" required value={sName} onChange={e=>setSName(e.target.value)} className="w-full p-2.5 bg-black/40 border border-white/10 rounded text-white focus:border-purple-500 outline-none transition-colors shadow-inner" />
              </div>

              <div className="grid grid-cols-2 gap-4 bg-purple-500/5 p-4 border border-purple-500/20 rounded-lg">
                 <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-1">Academic Branch</label>
                    <input list="branches" placeholder="Type or select branch..." required value={sBranch} onChange={e=>setSBranch(e.target.value.toUpperCase())} className="w-full p-2.5 bg-black/40 border border-white/10 rounded text-white focus:border-purple-500 outline-none transition-colors" />
                    <datalist id="branches">
                       <option value="CSE" label="Computer Science" />
                       <option value="ECE" label="Electronics & Comm." />
                       <option value="MECHANICAL" label="Mechanical" />
                       <option value="CIVIL" label="Civil Engineering" />
                       <option value="EEE" label="Electrical & Electronics" />
                    </datalist>
                 </div>
                 <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-1">Class Time</label>
                    <input type="text" placeholder="e.g. 10:00 AM - 11:30 AM" required value={sTime} onChange={e=>setSTime(e.target.value)} className="w-full p-2.5 bg-black/40 border border-white/10 rounded text-white focus:border-purple-500 outline-none transition-colors shadow-inner" />
                 </div>

                 <div>
                    <label className="block text-sm font-semibold text-gray-300 mb-1">Year of Study</label>
                    <input list="years" placeholder="Select Year (1-4)" required type="number" min="1" max="4" value={sYear} onChange={e=>setSYear(e.target.value)} className="w-full p-2.5 bg-black/40 border border-white/10 rounded text-white focus:border-purple-500 outline-none transition-colors" />
                    <datalist id="years">
                       <option value="1" />
                       <option value="2" />
                       <option value="3" />
                       <option value="4" />
                    </datalist>
                 </div>
              </div>

              <button type="submit" className="w-full py-3 rounded-lg font-bold text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 shadow-lg shadow-purple-500/25 transition-all outline-none mt-6">
                 Submit New Class to Database
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};

export default AdminDashboard;

