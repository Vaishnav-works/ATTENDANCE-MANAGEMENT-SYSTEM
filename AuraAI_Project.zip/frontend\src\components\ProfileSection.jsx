import React from 'react';
import { User, Mail, Hash, Book, Calendar, ShieldCheck } from 'lucide-react';

const ProfileSection = ({ user }) => {
  if (!user) return null;

  const isStudent = user.role === 'Student';
  const isFaculty = user.role === 'Faculty';

  return (
    <div className="glass-card overflow-hidden border-white/5 relative group mb-8">
      {/* Decorative Gradient Background */}
      <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-r from-indigo-500/20 via-purple-500/10 to-transparent"></div>
      
      <div className="p-6 pt-12 relative flex flex-col md:flex-row items-center md:items-end gap-6">
        {/* Profile Image */}
        <div className="relative">
          <div className="w-24 h-24 rounded-2xl overflow-hidden border-2 border-white/10 shadow-2xl group-hover:border-indigo-500/50 transition-all duration-500">
            <img 
              src={user.photo_url || `https://ui-avatars.com/api/?name=${user.name}&background=6366F1&color=fff`} 
              alt={user.name} 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="absolute -bottom-2 -right-2 p-1.5 bg-indigo-600 rounded-lg border border-white/10 shadow-lg text-white">
            {isStudent ? <User size={14} /> : <ShieldCheck size={14} />}
          </div>
        </div>

        {/* Identity Info */}
        <div className="flex-1 text-center md:text-left space-y-1">
          <h2 className="text-2xl font-black text-white tracking-tight">{user.name}</h2>
          <div className="flex flex-wrap justify-center md:justify-start gap-4 mt-2">
            <div className="flex items-center gap-2 text-gray-400 text-xs font-bold uppercase tracking-widest">
              <Mail size={14} className="text-indigo-400" />
              {user.email}
            </div>
            {isStudent && (
              <div className="flex items-center gap-2 text-gray-400 text-xs font-bold uppercase tracking-widest">
                <Hash size={14} className="text-purple-400" />
                Roll: {user.student_id}
              </div>
            )}
            {isFaculty && (
              <div className="flex items-center gap-2 text-gray-400 text-xs font-bold uppercase tracking-widest">
                <Hash size={14} className="text-green-400" />
                Faculty ID: {user.faculty_id}
              </div>
            )}
          </div>
        </div>

        {/* Academic/Professional Tags */}
        <div className="flex flex-wrap gap-2 justify-center md:justify-end">
          {user.branch && (
            <div className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg flex items-center gap-2 shadow-sm">
              <Book size={14} className="text-indigo-400" />
              <span className="text-[10px] font-black uppercase tracking-tighter text-gray-300">
                {isFaculty ? 'Department' : 'Branch'}: {user.branch}
              </span>
            </div>
          )}
          {isStudent && user.year && (
            <div className="px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg flex items-center gap-2 shadow-sm">
              <Calendar size={14} className="text-purple-400" />
              <span className="text-[10px] font-black uppercase tracking-tighter text-gray-300">
                Year: {user.year}
              </span>
            </div>
          )}
          {isFaculty && user.designation && (
            <div className="px-3 py-1.5 bg-indigo-500/10 border border-indigo-500/20 rounded-lg flex items-center gap-2 shadow-sm">
              <ShieldCheck size={14} className="text-indigo-400" />
              <span className="text-[10px] font-black uppercase tracking-tighter text-indigo-300">
                {user.designation}
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfileSection;
