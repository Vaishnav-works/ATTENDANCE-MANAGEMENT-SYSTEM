import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Navigate } from 'react-router-dom';
import { Users, ShieldCheck, Home, ArrowLeft } from 'lucide-react';

const Login = () => {
  const [selectedRole, setSelectedRole] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login, user } = useAuth();
  const [error, setError] = useState('');

  if (user) {
    return <Navigate to={`/${user.role.toLowerCase()}-dashboard`} replace />;
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    const success = await login(email, password);
    if (!success) setError('Invalid credentials or server error');
  };

  const handleQuickLogin = (roleEmail) => {
     setEmail(roleEmail);
     setPassword('aura123');
  };

  const renderRoleSelection = () => (
    <div className="space-y-4 w-full">
      <h2 className="text-xl font-semibold mb-6">Select your role to continue:</h2>
      <button 
         onClick={() => setSelectedRole('Student')}
         className="w-full flex items-center justify-between p-4 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-[#6366F1] transition-all rounded-lg group"
      >
         <div className="flex items-center gap-3">
             <div className="p-2 bg-[#6366F1]/20 text-[#6366F1] rounded-lg group-hover:scale-110 transition-transform">
                 <Users size={24} />
             </div>
             <div className="text-left">
                <p className="font-semibold text-lg leading-none">Student</p>
                <p className="text-xs text-gray-400 mt-1">Scan QR and view reports</p>
             </div>
         </div>
      </button>

      <button 
         onClick={() => setSelectedRole('Faculty')}
         className="w-full flex items-center justify-between p-4 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-green-500 transition-all rounded-lg group"
      >
         <div className="flex items-center gap-3">
             <div className="p-2 bg-green-500/20 text-green-500 rounded-lg group-hover:scale-110 transition-transform">
                 <Home size={24} />
             </div>
             <div className="text-left">
                <p className="font-semibold text-lg leading-none">Faculty</p>
                <p className="text-xs text-gray-400 mt-1">Generate QR and monitor attendance</p>
             </div>
         </div>
      </button>

      <button 
         onClick={() => setSelectedRole('Admin')}
         className="w-full flex items-center justify-between p-4 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-purple-500 transition-all rounded-lg group"
      >
         <div className="flex items-center gap-3">
             <div className="p-2 bg-purple-500/20 text-purple-500 rounded-lg group-hover:scale-110 transition-transform">
                 <ShieldCheck size={24} />
             </div>
             <div className="text-left">
                <p className="font-semibold text-lg leading-none">Admin</p>
                <p className="text-xs text-gray-400 mt-1">System configuration and hub</p>
             </div>
         </div>
      </button>

      <div className="mt-8 border-t border-white/10 pt-6">
         <p className="text-sm text-gray-400 italic">"Technology is best when it brings people together."</p>
      </div>
    </div>
  );

  const renderLoginForm = () => (
    <div className="w-full animate-in fade-in slide-in-from-right duration-300">
      <div className="flex items-center gap-3 mb-6">
         <button onClick={() => { setSelectedRole(null); setError(''); }} className="text-gray-400 hover:text-white transition-colors p-2 rounded-full hover:bg-white/10">
            <ArrowLeft size={20} />
         </button>
         <div>
            <span className="text-xs text-gray-400 block uppercase tracking-wider font-bold">Portal Access</span>
            <span className="text-white font-semibold">Logging in as <span className="text-indigo-400">{selectedRole}</span></span>
         </div>
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-300 p-4 rounded-lg mb-6 text-sm flex items-start gap-3 animate-shake">
          <div className="mt-0.5">⚠️</div>
          <div>{error}</div>
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="group relative">
            <input
              type="email"
              placeholder="Email Address"
              className="w-full p-4 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition-all"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
        </div>
        <div className="group relative">
            <input
              type="password"
              placeholder="Password"
              className="w-full p-4 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-indigo-500 transition-all"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
        </div>
        <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-4 rounded-xl transition-all shadow-xl shadow-indigo-600/20 active:scale-95">
          Sign In to Portal
        </button>
      </form>

      <div className="mt-10 border-t border-white/10 pt-8">
         <p className="text-xs text-gray-500 uppercase tracking-widest font-bold mb-4">Quick Diagnostic Access</p>
         <button 
            type="button"
            onClick={() => handleQuickLogin(`${selectedRole.toLowerCase()}1@aura.com`)}
            className="w-full text-xs bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 py-3 rounded-lg border border-indigo-500/30 transition-all font-medium flex items-center justify-center gap-2 group"
         >
            <span>Auto-fill valid {selectedRole} credentials</span>
            <span className="group-hover:translate-x-1 transition-transform">→</span>
         </button>
      </div>
    </div>
  );

  return (
    <div className="flex items-center justify-center min-h-screen p-4 text-white relative overflow-hidden">
      {/* Global Aura Background */}
      <div className="aura-bg"></div>
      <div className="aura-blob w-[500px] h-[500px] bg-indigo-500/20 -top-48 -left-48"></div>
      <div className="aura-blob w-[600px] h-[600px] bg-purple-500/10 -bottom-48 -right-48"></div>

      <div className="w-full max-w-md glass-card p-8 text-center border-[#6366F1]/30 z-10 shadow-2xl relative overflow-hidden backdrop-blur-xl">
        {/* Subtle glowing orb inside the card to compliment glass effect */}
        <div className="absolute -top-10 -right-10 w-32 h-32 bg-[#6366F1]/20 rounded-full blur-3xl pointer-events-none"></div>

        <div className="inline-block p-4 rounded-full bg-[#6366F1]/20 mb-6 border border-[#6366F1]/30">
           <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-300 to-[#6366F1] text-transparent bg-clip-text">AuraAI</h2>
        </div>
        
        <h1 className="text-2xl font-bold text-white mb-6">
           {selectedRole ? `Welcome, ${selectedRole}` : 'Login to Aura Portal'}
        </h1>
        
        {selectedRole ? renderLoginForm() : renderRoleSelection()}
      </div>
    </div>
  );
};

export default Login;

