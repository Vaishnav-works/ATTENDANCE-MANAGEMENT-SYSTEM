import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Bot, Sparkles, Loader2, Send } from 'lucide-react';
import API from '../api/api';

const AuraAI = () => {
  const [prompt, setPrompt] = useState('');
  const [history, setHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef(null);
  const { user } = useAuth();

  useEffect(() => {
    setHistory([{
      role: 'model',
      parts: [{ text: `Hello ${user?.name?.split(' ')[0] || 'there'}! ✨ I'm AuraAI, your personal attendance assistant.\n\nYou can ask me:\n• Your current attendance percentage\n• How many classes you can skip safely\n• Study tips or university queries\n\nHow can I help you today?` }]
    }]);
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleAskAI = async (e) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    const userMessage = prompt;
    setPrompt('');
    const updatedHistory = [...history, { role: 'user', parts: [{ text: userMessage }] }];
    setHistory(updatedHistory);
    setIsLoading(true);

    const contextData = `
      The user is ${user?.name || 'a student'}.
      Email: ${user?.email}.
      Role: ${user?.role}.
      Student ID: ${user?.student_id || 'Unknown'}.
      Overall Attendance: 82%. Attended 34 of 42 classes so far.
      If asked about attendance, state these numbers directly without asking for their ID.
    `;

    try {
      const response = await API.post('/chat/ask', {
        prompt: userMessage,
        history: history.map(h => ({ role: h.role, parts: h.parts })),
        contextData
      });

      if (response.data?.history) {
        setHistory(response.data.history);
      } else {
        setHistory([...updatedHistory, { role: 'model', parts: [{ text: "I'm having trouble connecting right now. Please try again shortly." }] }]);
      }
    } catch (err) {
      setHistory([...updatedHistory, { role: 'model', parts: [{ text: "My systems are currently offline. Please check your connection." }] }]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickPrompts = [
    "What is my attendance percentage?",
    "How many classes can I still miss?",
    "Give me tips to improve my attendance",
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] max-w-3xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700">

      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <div className="relative">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center shadow-[0_0_20px_rgba(139,92,246,0.4)]">
            <Bot size={28} className="text-white" />
          </div>
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-[#050504] animate-pulse" />
        </div>
        <div>
          <h1 className="text-3xl font-black bg-gradient-to-r from-purple-400 via-indigo-300 to-white bg-clip-text text-transparent italic tracking-tighter uppercase">
            AuraAI
          </h1>
          <p className="text-gray-500 text-sm font-medium italic">Your personal academic intelligence assistant</p>
        </div>
      </div>

      {/* Chat Window */}
      <div className="flex-1 glass-card flex flex-col overflow-hidden border-t-4 border-t-purple-500/70 relative">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-thin scrollbar-track-transparent scrollbar-thumb-white/10">
          {history.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              {msg.role === 'model' && (
                <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center mr-2 mt-1 flex-shrink-0">
                  <Sparkles size={12} className="text-white" />
                </div>
              )}
              <div className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                msg.role === 'user'
                  ? 'bg-indigo-600/40 text-indigo-100 rounded-br-sm'
                  : 'bg-white/8 text-gray-200 rounded-bl-sm border border-white/5'
              }`}>
                {msg.role === 'model' && (
                  <span className="text-[10px] font-black text-purple-400 uppercase tracking-widest block mb-1">AuraAI</span>
                )}
                <p className="whitespace-pre-wrap">{msg.parts[0].text}</p>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center mr-2 mt-1 flex-shrink-0">
                <Sparkles size={12} className="text-white animate-spin" />
              </div>
              <div className="bg-white/8 border border-white/5 px-4 py-3 rounded-2xl rounded-bl-sm flex items-center gap-3">
                <span className="text-[10px] font-black text-purple-400 uppercase tracking-widest">AuraAI</span>
                <Loader2 size={14} className="animate-spin text-purple-400" />
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Quick Prompts */}
        {history.length <= 1 && (
          <div className="px-6 pb-3 flex flex-wrap gap-2">
            {quickPrompts.map((q, i) => (
              <button
                key={i}
                onClick={() => setPrompt(q)}
                className="text-[11px] font-bold px-3 py-1.5 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-300 hover:bg-purple-500/20 transition-all"
              >
                {q}
              </button>
            ))}
          </div>
        )}

        {/* Input */}
        <form onSubmit={handleAskAI} className="p-4 border-t border-white/8 bg-black/20 flex gap-3">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Ask AuraAI anything..."
            className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500/30 text-sm transition-all"
          />
          <button
            type="submit"
            disabled={isLoading || !prompt.trim()}
            className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:opacity-30 disabled:cursor-not-allowed p-3 rounded-xl text-white transition-all shadow-[0_0_15px_rgba(139,92,246,0.3)] hover:scale-105 active:scale-95"
          >
            <Send size={18} />
          </button>
        </form>
      </div>
    </div>
  );
};

export default AuraAI;

